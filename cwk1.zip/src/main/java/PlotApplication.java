/**
 * JavaFX application to plot elevations of a GPS track, for the
 * Advanced task of COMP1721 Coursework 1.
 *
 * @author YOUR NAME HERE
 */
public class PlotApplication {

  // If attempting the Advanced task, implement your plotting code here.
  // You will need to modify this class definition so that it extends
  // javafx.application.Application

  public static void main(String[] args) {
    // If attempting the Advanced task, uncomment the line below
    //launch(args);
  }
}
