/**
 * Program to provide information on a GPS track stored in a file.
 *
 * @author YOUR NAME HERE
 */
public class TrackInfo {
  public static void main(String[] args) {
    // TODO: Implementation TrackInfo application here
  }
}
